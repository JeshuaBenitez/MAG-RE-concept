from pathlib import Path

import csv
import wave

import pretty_midi


ROOT = Path(__file__).resolve().parents[1]


def test_required_outputs_exist():
    for path in ("Motif.mid", "Tempo_80.wav", "Tempo_100.wav", "Tempo_120.wav", "results.csv"):
        assert (ROOT / path).exists(), path


def test_wavs_are_nonempty_and_same_sample_rate():
    durations = []
    for tempo in (80, 100, 120):
        with wave.open(str(ROOT / f"Tempo_{tempo}.wav"), "rb") as handle:
            assert handle.getframerate() == 44100
            assert handle.getnframes() > 0
            durations.append(handle.getnframes())
    assert durations[0] > durations[1] > durations[2]


def test_midi_variations_preserve_note_structure():
    counts = []
    for tempo in (80, 100, 120):
        midi = pretty_midi.PrettyMIDI(str(ROOT / f"Motif_{tempo}.mid"))
        counts.append(sum(len(instrument.notes) for instrument in midi.instruments))
    assert counts == [88, 88, 88]


def test_results_have_real_measurements():
    with (ROOT / "results.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert [int(row["requested_bpm"]) for row in rows] == [80, 100, 120]
    assert all(float(row["measured_bpm"]) > 0 for row in rows)
    assert all(float(row["absolute_error_bpm"]) >= 0 for row in rows)